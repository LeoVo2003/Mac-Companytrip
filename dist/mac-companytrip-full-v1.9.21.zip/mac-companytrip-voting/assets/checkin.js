(() => {
  const root = document.getElementById("mac-checkin-app");
  if (!root) return;
  const config = {
    restUrl: root.dataset.restUrl,
    nonce: root.dataset.nonce,
    logo: root.dataset.logo,
    logout: root.dataset.logout,
    dashboard: root.dataset.dashboard || root.dataset.logout,
  };
  const esc = (value) => String(value ?? "").replace(/[&<>'"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[char]));
  const remainingSeconds = (closesAt) => Math.max(0, Math.ceil((new Date(String(closesAt).replace(" ", "T") + "Z").getTime() - Date.now()) / 1000));
  const remainingClock = (closesAt) => {
    const seconds = remainingSeconds(closesAt);
    return `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
  };
  const windowLabel = () => `CỬA SỔ ${windowMinutes}'`;
  const windowLockedText = () => `Cửa sổ ${windowMinutes} phút đã hết`;
  const backLink = () => `<a class="mc-back" href="${esc(config.dashboard)}">← Quay lại dashboard</a>`;
  let bootstrap = null;
  let selectedTeamId = null;
  let view = "teams";
  let windowMinutes = 15;
  let flash = null;
  let scanning = false;
  let lastToken = "";
  let lastScanAt = 0;
  let videoStream = null;
  let raf = 0;

  const request = async (path, options = {}) => {
    const response = await fetch(config.restUrl + path, {
      credentials: "same-origin",
      headers: { "Content-Type": "application/json", "X-WP-Nonce": config.nonce, ...(options.headers || {}) },
      ...options,
    });
    const data = await response.json();
    if (!response.ok) {
      const error = new Error(data.message || "Không quét được QR.");
      error.payload = data.data || data;
      error.code = data.code || data.data?.code;
      throw error;
    }
    return data;
  };

  const stopCamera = () => {
    scanning = false;
    if (raf) cancelAnimationFrame(raf);
    raf = 0;
    if (videoStream) videoStream.getTracks().forEach((track) => track.stop());
    videoStream = null;
  };

  async function load() {
    try {
      bootstrap = await request("checkin/bootstrap");
      windowMinutes = Number(bootstrap.windowMinutes) > 0 ? Number(bootstrap.windowMinutes) : 15;
      if (!selectedTeamId && bootstrap.allowedTeams?.length) selectedTeamId = String(bootstrap.allowedTeams[0].teamId);
      if (selectedTeamId && !bootstrap.allowedTeams?.some((team) => String(team.teamId) === String(selectedTeamId))) {
        selectedTeamId = bootstrap.allowedTeams?.[0] ? String(bootstrap.allowedTeams[0].teamId) : null;
      }
      render();
      if (view === "scanner") await startCamera();
    } catch (err) {
      root.innerHTML = `<main class="mc-shell"><section class="mc-card"><p class="mc-kicker">CHECK-IN</p><h1>Không mở được camera quét</h1><p class="mc-meta">${esc(err.message)}</p></section></main>`;
    }
  }

  function currentTeam() {
    return (bootstrap?.allowedTeams || []).find((team) => String(team.teamId) === String(selectedTeamId)) || bootstrap?.allowedTeams?.[0] || null;
  }

  function memberRows(team) {
    const rows = [
      ...(team.checkedInMembers || []).map((member) => ({ ...member, state: "done" })),
      ...(team.missingMembers || []).map((member) => ({ ...member, state: "missing" })),
      ...(team.exemptedMembers || []).map((member) => ({ ...member, state: "exempt" })),
    ].sort((a, b) => String(a.fullName).localeCompare(String(b.fullName), "vi"));
    return rows.map((member) => `<li class="${member.state}"><span>${esc(member.fullName)}</span><small>${member.state === "done" ? "✓ Đã quét" : member.state === "exempt" ? "Miễn" : "Chưa quét"}</small></li>`).join("") || `<li class="missing"><span>Chưa có thành viên</span><small></small></li>`;
  }

  function teamsView(checkpoint) {
    const teams = bootstrap?.allowedTeams || [];
    return `<main class="mc-shell"><header class="mc-top"><img src="${esc(config.logo)}" alt="MAC Marketing">${backLink()}</header><section class="mc-card"><p class="mc-kicker">CHECK-IN · TRẠM ${checkpoint.id}</p><h1>Chọn team để quét</h1><p class="mc-meta">${esc(checkpoint.name)} · chạm vào một team để mở camera quét và danh sách thành viên.</p><ul class="mc-team-pick">${teams.map((item) => { const ratio = item.eligible ? Math.round((item.checkedIn / item.eligible) * 100) : 0; return `<li><button type="button" data-pick-team="${item.teamId}"><span class="mc-pick-name">#${item.teamNumber} ${esc(item.teamName)}</span><span class="mc-pick-meta"><strong>${item.checkedIn}/${item.eligible}</strong><small>${item.completed ? "Đã đủ" : item.windowLocked ? "Hết giờ" : `${ratio}%`}</small></span></button></li>`; }).join("")}</ul></section></main>`;
  }

  function render() {
    const team = currentTeam();
    const checkpoint = bootstrap?.activeCheckpoint;
    if (!checkpoint) {
      stopCamera();
      root.innerHTML = `<main class="mc-shell"><header class="mc-top"><img src="${esc(config.logo)}" alt="MAC Marketing">${backLink()}</header><section class="mc-card mc-empty"><p class="mc-kicker">CHECK-IN</p><h1>Chưa có trạm check-in nào đang mở</h1><p class="mc-meta">Đợi admin mở một trạm check-in rồi tải lại trang.</p></section></main>`;
      return;
    }
    if (!team) {
      stopCamera();
      root.innerHTML = `<main class="mc-shell"><header class="mc-top"><img src="${esc(config.logo)}" alt="MAC Marketing">${backLink()}</header><section class="mc-card mc-empty"><p class="mc-kicker">CHECK-IN</p><h1>Chưa được gán team</h1><p class="mc-meta">Nhờ admin gán team cho tài khoản BTC này.</p></section></main>`;
      return;
    }
    if (view === "teams") {
      stopCamera();
      root.innerHTML = teamsView(checkpoint);
      root.querySelectorAll("[data-pick-team]").forEach((button) => button.addEventListener("click", () => {
        selectedTeamId = button.dataset.pickTeam;
        flash = null;
        view = "scanner";
        render();
        startCamera();
      }));
      return;
    }
    const ratio = team.eligible ? Math.round((team.checkedIn / team.eligible) * 100) : 0;
    const flashHtml = flash ? `<div class="mc-flash ${flash.type}" role="status">${esc(flash.text)}</div>` : "";
    const windowHtml = team.windowLocked
      ? `<div class="mc-window locked"><span>ĐÃ KHÓA</span><strong>${windowLockedText()}</strong></div>`
      : team.windowClosesAt
        ? `<div class="mc-window live" data-window-closes="${esc(team.windowClosesAt)}"><span>${windowLabel()}</span><strong>Còn ${remainingClock(team.windowClosesAt)}</strong></div>`
        : `<div class="mc-window idle"><span>${windowLabel()}</span><strong>Mở ở lượt quét đầu tiên</strong></div>`;
    const doneHtml = team.completed ? `<div class="mc-done"><span>TEAM ĐÃ ĐỦ</span><strong>${team.checkedIn} / ${team.eligible}</strong><p>Hoàn thành ${esc(team.completedAt || "")}${team.temporaryRank ? ` · Hạng tạm thời #${team.temporaryRank}` : ""}</p></div>` : "";
    root.innerHTML = `<main class="mc-shell"><header class="mc-top"><img src="${esc(config.logo)}" alt="MAC Marketing"><button type="button" class="mc-back" id="mc-back-teams">← Chọn team</button></header><section class="mc-card"><p class="mc-kicker">CHECK-IN — TEAM ${team.teamNumber}</p><h1>${esc(team.teamName)}</h1><p class="mc-meta">TRẠM ${checkpoint.id} · ${esc(checkpoint.name)}</p>${windowHtml}<div class="mc-progress"><strong>${team.checkedIn} / ${team.eligible}</strong><div class="mc-bar" aria-hidden="true"><b style="width:${ratio}%"></b></div></div>${flashHtml}${doneHtml}<div class="mc-camera"><video id="mc-video" playsinline muted autoplay></video><canvas id="mc-canvas"></canvas><div class="mc-frame" aria-hidden="true"></div></div><p class="mc-kicker">THÀNH VIÊN · ${team.checkedIn}/${team.eligible}</p><ul class="mc-members">${memberRows(team)}</ul></section></main>`;
    root.querySelector("#mc-back-teams")?.addEventListener("click", () => { view = "teams"; flash = null; render(); });
  }

  async function startCamera() {
    stopCamera();
    const video = root.querySelector("#mc-video");
    const canvas = root.querySelector("#mc-canvas");
    if (!video || !canvas || !window.jsQR) return;
    try {
      videoStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: "environment" } }, audio: false });
      video.srcObject = videoStream;
      await video.play();
      scanning = true;
      const context = canvas.getContext("2d", { willReadFrequently: true });
      const tick = () => {
        if (!scanning) return;
        if (video.readyState >= 2) {
          canvas.width = video.videoWidth;
          canvas.height = video.videoHeight;
          context.drawImage(video, 0, 0, canvas.width, canvas.height);
          const image = context.getImageData(0, 0, canvas.width, canvas.height);
          const result = window.jsQR(image.data, image.width, image.height, { inversionAttempts: "dontInvert" });
          if (result?.data) handleToken(result.data);
        }
        raf = requestAnimationFrame(tick);
      };
      tick();
    } catch (err) {
      flash = { type: "err", text: "Không mở được camera. Hãy cấp quyền camera cho trình duyệt." };
      render();
    }
  }

  function applyTeam(progress) {
    bootstrap.allowedTeams = (bootstrap.allowedTeams || []).map((team) => String(team.teamId) === String(progress.teamId) ? progress : team);
    selectedTeamId = String(progress.teamId);
    const team = currentTeam();
    if (!team) return;
    const ratio = team.eligible ? Math.round((team.checkedIn / team.eligible) * 100) : 0;
    const strong = root.querySelector(".mc-progress strong");
    const bar = root.querySelector(".mc-bar b");
    const members = root.querySelector(".mc-members");
    if (strong) strong.textContent = `${team.checkedIn} / ${team.eligible}`;
    if (bar) bar.style.width = `${ratio}%`;
    if (members) members.innerHTML = memberRows(team);
    const windowBox = root.querySelector(".mc-window");
    if (windowBox) {
      windowBox.className = `mc-window ${team.windowLocked ? "locked" : team.windowClosesAt ? "live" : "idle"}`;
      if (team.windowClosesAt) windowBox.dataset.windowCloses = team.windowClosesAt;
      else delete windowBox.dataset.windowCloses;
      const label = windowBox.querySelector("span");
      const value = windowBox.querySelector("strong");
      if (label && value) {
        if (team.windowLocked) { label.textContent = "ĐÃ KHÓA"; value.textContent = windowLockedText(); }
        else if (team.windowClosesAt) { label.textContent = windowLabel(); value.textContent = `Còn ${remainingClock(team.windowClosesAt)}`; }
        else { label.textContent = windowLabel(); value.textContent = "Mở ở lượt quét đầu tiên"; }
      }
    }
  }

  function showFlash(type, text) {
    flash = { type, text };
    let box = root.querySelector(".mc-flash");
    if (!box) {
      box = document.createElement("div");
      box.className = "mc-flash";
      box.setAttribute("role", "status");
      const camera = root.querySelector(".mc-camera");
      if (camera) camera.insertAdjacentElement("beforebegin", box);
      else return;
    }
    box.className = `mc-flash ${type}`;
    box.textContent = text;
  }

  async function handleToken(raw) {
    let token = String(raw || "").trim();
    const marker = "/company-trip/q/";
    const markerAt = token.lastIndexOf(marker);
    if (markerAt !== -1) token = token.slice(markerAt + marker.length).split(/[?#]/)[0].trim();
    if (!token || (token === lastToken && Date.now() - lastScanAt < 2500)) return;
    lastToken = token;
    lastScanAt = Date.now();
    const checkpoint = bootstrap?.activeCheckpoint;
    if (!checkpoint) return;
    try {
      const result = await request("checkin/scan", { method: "POST", body: JSON.stringify({ checkpointId: checkpoint.id, token }) });
      applyTeam(result.teamProgress);
      showFlash("ok", `✓ ${result.voter.fullName} · ${result.teamProgress.checkedIn}/${result.teamProgress.eligible}`);
    } catch (err) {
      const extra = err.payload || {};
      if (extra.teamProgress) applyTeam(extra.teamProgress);
      const locked = extra.code === "WINDOW_LOCKED" || extra.code === "window_locked";
      const type = locked ? "err" : extra.code === "ALREADY_CHECKED_IN" || extra.code === "already_checked_in" ? "warn" : "err";
      const scannedNote = extra.scanned ? ` [quét thấy: ${extra.scanned}]` : "";
      showFlash(type, (locked ? `${windowLockedText()}. ${err.message}` : err.message) + scannedNote);
    }
  }

  window.addEventListener("pagehide", stopCamera);
  setInterval(() => {
    root.querySelectorAll("[data-window-closes]").forEach((box) => {
      const seconds = remainingSeconds(box.dataset.windowCloses);
      const value = box.querySelector("strong");
      if (!value) return;
      if (seconds <= 0) {
        box.classList.remove("live");
        box.classList.add("locked");
        const label = box.querySelector("span");
        if (label) label.textContent = "ĐÃ KHÓA";
        value.textContent = windowLockedText();
        delete box.dataset.windowCloses;
      } else {
        value.textContent = `Còn ${remainingClock(box.dataset.windowCloses)}`;
      }
    });
  }, 1000);
  load();
})();
